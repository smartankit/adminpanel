## Steps of running this project
from the command prompt clone the project
* $git clone https://github.com/techsithgit/ng5-jasmin-karma-test.git
* $cd ng5-jasmin-karma-test
* $npm install
* $npm start
* $npm install karma-firefox-launcher --save-dev

[Watch the Tutorial](https://youtu.be/D6qPDww2X8k).

## Other commands
* $ng new ng5-jasmin-karma-test // Create a new project using Angular CLI
* $ng g service test // Create a new service called test
