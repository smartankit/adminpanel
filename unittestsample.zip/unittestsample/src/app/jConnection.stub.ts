export class JConnectionStub {
    public stub: any = {};
    public url: string;
    
    constructor() {
        this.stub.callLog = [];
        this.stub.onFunctionDict = {};
        this.stub.doneFunc = null;
        this.stub.failFunc = null;
        this.stub.errorFunc = null;
    }

    createHubProxy() {
        return new JHubProxyStub();
    }
    
    error(errorFunc: any) {
        this.stub.callLog.push('connection.error');
        this.stub.errorFunc = errorFunc;
    };

    start () {
        this.stub.callLog.push('connection.start');
        return new JPromiseStub();
    };

    stop () {
        this.stub.callLog.push('connection.stop');
        return new JPromiseStub();
    };

    get id(): string {
        return '8bc90864-5f86-4f01-8e51-e21e5b326eb2';
    }

    starting() { }
    received() { }
    connectionSlow() { }
    reconnecting() { }
    reconnected() { }
    stateChanged() { }
    disconnected() { }
}

export class JHubProxyStub { 

    on(namedMessage: string, functionToCall: any) { 

    }
}

 
export class JPromiseStub { 

    done() { }
    fail() { }
}