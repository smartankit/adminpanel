/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ChannelService, SignalrWindow, ChannelConfig,ConnectionState } from './channel.service';
import { Globals } from './globals';
import { EventEmitter, state } from '@angular/core';
import "rxjs/add/operator/map";
import { Observable, ReplaySubject } from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';


let service: ChannelService;
let receiveMessage;
const mockError = 'TEST ERROR';
let mockChannel = 'test';
let doneFail = {};
doneFail = {
  done: () => {
    return doneFail;
  },
  fail: (error) => {
    return doneFail;
  }
};

const fakeGlobals = {

  window: {

    handler: Function,

    addEventListener: (event, handler: Function) => {

      this.handler = handler;

    },

    '$':

      {

        hubConnection: () => {

          return {

            start: () => {

              return doneFail;

            },

            qs: null,

            logging: false,

            url: 'http://localhost:9876/signalr',
            useDefaultPath: false,
            proxies: {

              invoke: {}

            },



            createHubProxy: (channelHub: string) => {

              return {

                on: (receiveMessage: string, hubProxyFunc: any) => {

                  return receiveMessage;
                },

                invoke: (name: string, channel: string) => {

                  return doneFail;

                },

              };

            },

            stateChanged: (state: any) => { },

            error: (error) => { }

          };

        }

      },



    fireClose: () => {

      this.handler();

    }

  },

  navigator: {

    userAgent: 'test',

    platform: 'mocha'

  }

};

describe('Service: Channel', () => {

  let channelConfig = new ChannelConfig();
  channelConfig.url = "http://localhost:9876/signalr";
  channelConfig.hubName = "EventHub";

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [


        { provide: Globals, useValue: fakeGlobals },
        { provide: SignalrWindow, useValue: window },
        { provide: 'channel.config', useValue: channelConfig },
        ChannelService]
    });



    service = TestBed.get(ChannelService);

  });

  it('should ...', inject([ChannelService], (service: ChannelService) => {
    expect(service).toBeTruthy();
  }));
});


describe('#sub', () => {

  it('Should proxy on event', () => {
    let hubConnection = service['hubConnection'];
   
    let hubProxy = service['hubProxy'];

    let onCallback;
    spyOn(hubProxy, 'on').and.callFake((onEvent, callback) => onCallback = callback);
  
   
    //Creates channel subject for the first time and add it to subjects collection


    //expect(hubProxy.on).toHaveBeenCalled();
    


  });

  it('should notify of state change', (done) => {
    let stateChange;
    let hubConnection = service['hubConnection'];
   
    spyOn(hubConnection, 'stateChanged').and.callFake((callback) => stateChange = callback);
    hubConnection.start();
  
    service.connectionState$.subscribe(state=>{
      (res)=>console.log(res);
      expect(state).toBeDefined();
      expect(hubConnection.stateChanged).toHaveBeenCalled();
      done();
    })

    stateChange({ newState: hubConnection.connected });
    
    
  });

  it('should notify of errors', async((done) => {
    let errorCallback;
    let hubConnection = service['hubConnection'];
    console.log(hubConnection);
    spyOn(hubConnection, 'error').and.callFake((event,callback) => errorCallback = callback);
    service.error$.subscribe((error)=>{
      expect(error).toBeDefined();
      done();
    })

}));

});

function onCallback() {
  return ({ id: 'one' });
}
function errorCallback(){
  return {};
}