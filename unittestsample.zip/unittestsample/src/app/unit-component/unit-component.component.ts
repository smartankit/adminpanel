import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unit-component',
  templateUrl: './unit-component.component.html',
  styleUrls: ['./unit-component.component.css']
})
export class UnitComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
