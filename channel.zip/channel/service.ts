import { 
    Injectable,
    Inject,
    InjectionToken
} from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { User } from 'oidc-client';
import {
    ChannelEvent,
    ChannelSubject
} from '.';
import { AuthService } from './../auth/service';
import { Globals } from './../../globals';

export enum ChannelConnectionState {  
    Connecting = 1,
    Connected = 2,
    Reconnecting = 3,
    Disconnected = 4
}

export const HUB_URL = new InjectionToken('channel.HubURL');

@Injectable()
export class ChannelService {

    public starting$: Observable<any>;
    public connectionState$: Observable<ChannelConnectionState>;
    public error$: Observable<string>;

    private connectionStateSubject = new Subject<ChannelConnectionState>();
    private startingSubject = new Subject<any>();
    private errorSubject = new Subject<any>();

    private hubConnection: any;
    private hubProxy: any;

    private subjects = new Array<ChannelSubject>();

    constructor(
        @Inject(HUB_URL) private hubUrl: string,
        @Inject(AuthService) private auth: AuthService,
        @Inject(Globals) private globals: Globals
    ) {
        if (globals.window.$ === undefined || globals.window.$.hubConnection === undefined) {
            throw new Error('The variable \'$\' or the .hubConnection() function are not defined...please check the SignalR scripts have been loaded properly');
        }

        this.connectionState$ = this.connectionStateSubject.asObservable();
        this.error$ = this.errorSubject.asObservable();
        this.starting$ = this.startingSubject.asObservable();

        this.hubConnection = globals.window.$.hubConnection();
        this.hubConnection.url = this.hubUrl;
        this.hubProxy = this.hubConnection.createHubProxy('channelHub');

        this.hubConnection.stateChanged((state: any) => {
            let newState = ChannelConnectionState.Connecting;

            switch (state.newState) {
                case globals.window.$.signalR.connectionState.connecting:
                    newState = ChannelConnectionState.Connecting;
                    break;
                case globals.window.$.signalR.connectionState.connected:
                    newState = ChannelConnectionState.Connected;
                    break;
                case globals.window.$.signalR.connectionState.reconnecting:
                    newState = ChannelConnectionState.Reconnecting;
                    break;
                case globals.window.$.signalR.connectionState.disconnected:
                    newState = ChannelConnectionState.Disconnected;
                    break;
            }
            this.connectionStateSubject.next(newState);
        });

        this.hubConnection.error((error: any) => {
            this.errorSubject.next(error);
        });

        this.hubProxy.on('receiveMessage', (channel: string, data: string) => {
            let channelSub = this.subjects.find((x: ChannelSubject) => {
                return x.channel === channel;
            }) as ChannelSubject;

            if (channelSub !== undefined) {
                const channelEvent = new ChannelEvent();
                channelEvent.channelName = channel;
                channelEvent.data = data;
                channelEvent.json = JSON.parse(data);

                return channelSub.subject.next(channelEvent);
            }
        });

    }

    public start(): void {
        if (this.auth.currentUser) {
            this.startWithUser(this.auth.currentUser);
        }
        this.auth.userLoadedEvent.subscribe((user: User) => {
            console.log('Waiting to start websocket until user authenticated.');
            this.startWithUser(user);
        });
    }

    public sub(channel: string): Observable<ChannelEvent> {

        let channelSub = this.subjects.find((x: ChannelSubject) => {
            return x.channel === channel;
        }) as ChannelSubject;

        if (channelSub !== undefined) {
            return channelSub.subject.asObservable();
        }

        channelSub = new ChannelSubject();
        channelSub.channel = channel;
        channelSub.subject = new Subject<ChannelEvent>();
        this.subjects.push(channelSub);

        this.starting$.subscribe(() => {
            if (!this.auth.currentUser) {
                channelSub.subject.error(
                    new Error('Attempting to subscribe to a channel without an authenticated user.')
                )
            } else {
                this.hubProxy.invoke('subscribeChannel', channel)
                    .done(() => {
                        console.log(`Successfully subscribed to ${channel} channel`);
                    })
                    .fail((error: any) => {
                        channelSub.subject.error(error);
                    });
            }
            
        }, (error: any) => {
            channelSub.subject.error(error);
        });

        return channelSub.subject.asObservable();
    }

    private startWithUser(user: User) {
        this.addAuth(user);

        this.hubConnection.start()
            .done(() => {
                this.startingSubject.next();
            })
            .fail((error: any) => {
                this.startingSubject.error(error);
            });
    }

    private addAuth(user: User) {
        console.log('Adding user to websocket hub');

        this.hubConnection.qs = { 
            access_token: user.access_token
        };
    }

    // Not quite sure how to handle this (if at all) since there could be
    //  more than 1 caller subscribed to an observable we created
    //
    // unsubscribe(channel: string): Rx.Observable<any> {
    //     this.observables = this.observables.filter((x: ChannelObservable) => {
    //         return x.channel === channel;
    //     });
    // }
}