import { Subject } from 'rxjs/Subject';
import { ChannelEvent } from './channelEvent';

export class ChannelSubject {  
    channel: string;
    subject: Subject<ChannelEvent>;
}