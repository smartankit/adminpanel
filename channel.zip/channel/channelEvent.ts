export class ChannelEvent {
    channelName: string;
    timestamp: Date;
    data: string;
    json: any;

    constructor() {
        this.timestamp = new Date();
    }
}