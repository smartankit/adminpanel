import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ChannelService, ChannelConfig, SignalrWindow} from "./channel.service";
import "rxjs/add/operator/map";
import { AppComponent } from './app.component';
import { TaskComponent }  from "./task/task.component";
import { HttpModule }     from '@angular/http';
let channelConfig = new ChannelConfig();  
channelConfig.url = "http://localhost:36823";  
channelConfig.hubName = "EventHub";


@NgModule({
  declarations: [
    AppComponent,
    TaskComponent 
  ],
  imports: [
    BrowserModule,HttpModule 
  ],
  providers: [
    ChannelService, 
    { provide: SignalrWindow, useValue: window },
    { provide: 'channel.config', useValue: channelConfig }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
