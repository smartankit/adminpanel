export class ChannelEvent {
    channelName: string;
    timestamp: Date;
   
    Data: any;
    json: any;

    constructor() {
        this.timestamp = new Date();
    }
}